package com.authentic.smartdoor

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SecureDoorApplication : Application()